import timeseries_pkg.timeseries as timeseries

class Model():
    '''represents a timeseries model'''
    
    def __init__(self, data_dictionary, model_target, **args):
        #Initialize the time series model
        
        timeseries = self.timeseries = timeseries.Wrapper(dict=data_dictionary, **args)
        timeseries.series = timeseries.Apply('Fill_Gaps')
        
        ar_args = dict()
        ar_args['na'] = 1
        ar_args['target'] = 'LogEC'
        ar_args['nb'] = []
        
        ar_model = timeseries.ARX(ar_args)
        ar_model.residuals